Hey! I see that you installed my first datapack Flourish Vanilla. I am still working into it. Updates will release on the website and you can download from there.

Keep in mind the rights to every single resource pack, mod, shader, and datapack goes to the respective owner.

Thanks for playing! 

~Datfox

P.S. 
I am also looking for people that are wishing to make a progression guide for my datapack. You can be creative! Just send it to my discord: FoxOhYeah. It can be a video, document, etc, and it will be posted (with credit) in the Flourish Vanilla Discord.

Discord: https://discord.gg/fHj9yhm6FV