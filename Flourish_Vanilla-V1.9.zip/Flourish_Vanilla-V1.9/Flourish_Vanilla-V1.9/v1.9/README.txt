Hey! I see that you installed my first datapack Flourish Vanilla. I am still working into it. Updates will release on the website and you can download from there.

Keep in mind the rights to every single resource pack, mod, shader, and datapack goes to the respective owner. Credits on the GitHub.

Thanks for playing! 

~Datfox

P.S. 
I am also looking for people that are wishing to make a progression guide for my datapack. You can be creative! Just send it on the Discord server. It can be a video, document, etc, and it will be posted (with credit) in the Flourish Vanilla Discord.

Discord: https://discord.gg/fHj9yhm6FV

Updates on: https://flourishvanilla.github.io/

You can modify this all you want. While most of the mods I added are QOL or for pure looks, End Remastered (part of v1.9) is something that really makes the progression better. Please do consider installing Fabric. While the mod is playable without it, the true exploring purpose of this pack is achieved through this mod.